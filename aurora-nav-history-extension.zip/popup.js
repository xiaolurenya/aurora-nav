/* Aurora Nav · 历史记录一键导入扩展 v2
 * 关键：/api/import 需要管理员会话，所以这里用管理员密码登录（不是前台访问密码）。
 * 流程：读本机历史 -> 去重过滤 -> 生成可编辑的 JSON -> 打开后台导入页 -> 粘贴预览确认。
 */
const $ = id => document.getElementById(id);
const status = (msg, cls) => { const el = $('status'); el.textContent = msg; el.className = cls; };

chrome.storage.local.get(['base'], r => { if (r.base) $('base').value = r.base; });

function normalize(u) { return String(u || '').trim().replace(/\/+$/, ''); }
function skip(url) {
  if (!/^https?:\/\//.test(url)) return true;
  if (/^(chrome|edge|about|file|ftp|view-source|devtools|chrome-extension|moz-extension):/i.test(url)) return true;
  if (/\.(js|css|png|jpe?g|gif|webp|svg|ico|woff2?|mp4|mp3|json|xml)(\?|$)/i.test(url)) return true;
  return false;
}
function clean(u) {
  try {
    const x = new URL(u); x.hash = '';
    for (const k of [...x.searchParams.keys()]) if (/^(utm_|fbclid|gclid|spm|ref|from|_ga)/i.test(k)) x.searchParams.delete(k);
    return x.toString().replace(/\/$/, '');
  } catch { return ''; }
}
function dedupe(items) {
  const map = new Map();
  for (const it of items) {
    const u = clean(it.url);
    if (!u || skip(u)) continue;
    let key; try { const x = new URL(u); key = x.hostname + x.pathname.replace(/\/$/, ''); } catch { continue; }
    const prev = map.get(key);
    if (prev) { prev.visits += (it.visitCount || 1); if (it.title && !prev.title) prev.title = it.title; }
    else map.set(key, { url: u, title: it.title || '', visits: it.visitCount || 1 });
  }
  return [...map.values()].sort((a, b) => b.visits - a.visits);
}

// 用管理员密码换取后台会话（/api/import 需要 admin）
async function ensureAdmin(base, password) {
  const m = await fetch(base + '/api/meta', { credentials: 'include' }).then(r => r.json()).catch(() => null);
  if (m?.data?.admin) return true;
  if (!password) throw new Error('请填写管理员密码（导入接口需要后台权限）');
  const r = await fetch(base + '/api/login', {
    method: 'POST', credentials: 'include',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ type: 'admin', password }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.ok) throw new Error(j.error || '管理员密码错误');
  return true;
}

$('go').onclick = async () => {
  const btn = $('go');
  const base = normalize($('base').value);
  if (!base) return status('请先填写导航页地址', 'err');
  chrome.storage.local.set({ base });
  btn.disabled = true;
  status('正在读取本机历史记录…', 'info');
  try {
    const days = Number($('days').value) || 30;
    const max = Number($('limit').value) || 500;
    const startTime = Date.now() - days * 24 * 3600 * 1000;
    const raw = await chrome.history.search({ text: '', startTime, maxResults: Math.min(max * 3, 10000) });
    const items = dedupe(raw.map(x => ({ url: x.url, title: x.title, visitCount: x.visitCount || 1 }))).slice(0, max);
    if (!items.length) throw new Error('这个时间范围内没有可用的历史记录');

    await ensureAdmin(base, $('password').value);
    const payload = JSON.stringify({ Browser_History: items.map(x => ({ url: x.url, title: x.title, visitCount: x.visits })) });

    // 服务端做自动识别 + 去重预览
    const prev = await fetch(base + '/api/import', {
      method: 'POST', credentials: 'include',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ kind: 'history', text: payload }),
    }).then(r => r.json());
    if (!prev.ok) throw new Error(prev.error || '预览失败（请确认填的是管理员密码）');

    const selected = prev.data.items.map((x, i) => String(i)).filter((_, i) => !prev.data.items[i].exists);
    if (!selected.length) { status('这些历史记录都已存在，没有需要导入的新站点', 'info'); return; }

    const commit = await fetch(base + '/api/import', {
      method: 'POST', credentials: 'include',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ kind: 'history', text: payload, commit: true, selected }),
    }).then(r => r.json());
    if (!commit.ok) throw new Error(commit.error || '导入失败');

    // 把同一份 JSON 存到剪贴板，方便在后台逐条修改名称/网址后再导入
    await navigator.clipboard.writeText(payload).catch(() => {});
    const cats = [...new Set(prev.data.items.filter((_, i) => selected.includes(String(i))).map(x => x.suggestion?.category).filter(Boolean))];
    status('完成！导入 ' + commit.data.added + ' 个网站，自动分类：' + cats.slice(0, 6).join('、') + (cats.length > 6 ? ' 等' : '') + '。JSON 已复制到剪贴板，可在后台导入页修改后重导。', 'ok');

    // 自动打开后台导入页（已是管理员会话，可直接查看与编辑）
    chrome.tabs.create({ url: base + '/admin' });
  } catch (e) {
    status('失败：' + (e.message || e), 'err');
  } finally {
    btn.disabled = false;
  }
};
